tail -f \
~/boost/tools/docca/example/build_output.txt \
~/boost/libs/static_string/doc/build_output.txt \
~/boost/libs/url/doc/build_output.txt \
~/boost/libs/json/doc/build_output.txt \
~/boost/libs/beast/doc/build_output.txt
